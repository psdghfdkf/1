﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ResourcesAndStyles
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void clearStr_Click(object sender, RoutedEventArgs e)
        {
            str.Text = "";
            count.Text = "0";
        }

        private void setStr_Click(object sender, RoutedEventArgs e)
        {
            char num = count.Text.Last();

            string endText;
            switch (num)
            {
                case '0':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    endText = " грибов";
                    break;
                case '1':
                    endText = " гриб";
                    break;
                case '2':
                case '3':
                case '4':
                    endText = " гриба";
                    break;
                default:
                    endText = " Ошибка!";
                    break;
            }

            str.Text = "Мы нашли в лесу " + count.Text + endText;
        }
    }
}
